document.getElementById('resizeButton').addEventListener('click', function() {
    // تغيير الأبعاد إلى 1080x1080
    document.body.style.width = '1080px';
    document.body.style.height = '1080px';
    document.getElementById('screen').style.width = '1080px';
    document.getElementById('screen').style.height = '1080px';
});
